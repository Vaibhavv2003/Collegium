// const Razorpay=require('razorpay');
// const {RAZORPAY_ID_KEY,RAZORPAY_SECRET_KEY}=process.env;

// const razorpayInstance= new Razorpay({
//     key_id:RAZORPAY_ID_KEY,
//     key_secret:RAZORPAY_SECRET_KEY
// })

module.exports.createOrder=function(req,res){
    return res.send("payment");
}
